angular.module('loadTest', [])
    .controller('LoadTestController', ['$scope', '$http', '$timeout', function ($scope, $http, $timeout) {
        // For each provided URL, spin off a test thread with a timeout
        // For each group of provided URLs, spin off n test threads with the given timeout
        var runningTests = [];
        var testURLs = [];
        $scope.failedRequests = [];

        /* Test configuration */
        $scope.getFrequency = 1;
        $scope.numThreads = 2;
        $scope.timeout = 5000;
        $scope.urlsToPing = "/\n" + // Airfi Homepage (index.html)
        "/content/airfi/games/2048/index.html\n" + // A game URL for good measure
        "/getId\n" + // And a few URLs that are served by node to test node
        "/flight\n" + // And some that are served by Couch
        "/flight/AirFiProfile:OV\n" +
        "/unidentify\n" +
        "/content/OV/shop/images/10_parmesanisigar.png\n/content/OV/shop/images/11_vinnutatud_veiseliha.png\n/content/OV/shop/images/12_kana_koogiviljasupp.png\n/content/OV/shop/images/13_mesikapp_sokolaad.png\n/content/OV/shop/images/14_anneke_sokolaad.png\n/content/OV/shop/images/15_milka_kaerakupsis.png\n/content/OV/shop/images/16_pahklid.png\n/content/OV/shop/images/17_muffin.png\n/content/OV/shop/images/18_ouna_apelsini_tomatimahl.png\n/content/OV/shop/images/19_schweppes.png\n/content/OV/shop/images/1_wrap.png\n/content/OV/shop/images/20_limpa_mahlajoogid.png\n/content/OV/shop/images/21_gaseeritud_vesi.png\n/content/OV/shop/images/22_evian_vesi.png\n/content/OV/shop/images/23_coca_fanta.png\n/content/OV/shop/images/24_kohv_tee.png\n/content/OV/shop/images/25_alkohol_5cl.png\n/content/OV/shop/images/26_olu.png\n/content/OV/shop/images/27_vahuvein.png\n/content/OV/shop/images/28_punane_valge_vein.png\n/content/OV/shop/images/29_downtown.png\n/content/OV/shop/images/2_voileib.png\n/content/OV/shop/images/30_boss_ma_vie.png\n/content/OV/shop/images/31_dkny_golden.png\n/content/OV/shop/images/32_ck_free.png\n/content/OV/shop/images/33_armani_code_ice.png\n/content/OV/shop/images/34_antonio_banderas.png\n/content/OV/shop/images/35_sekonda.png\n/content/OV/shop/images/36_daniel_wellington.png\n/content/OV/shop/images/37_festina.png\n/content/OV/shop/images/38_silmalainer.png\n/content/OV/shop/images/39_ripsmetuss.png\n/content/OV/shop/images/3_mitmeviljaleivake.png\n/content/OV/shop/images/40_naokreem.png\n/content/OV/shop/images/41_silmakreem.png\n/content/OV/shop/images/42_komplekt.png\n/content/OV/shop/images/43_katepuhastusratikud.png\n/content/OV/shop/images/44_habemeajamispalsam.png\n/content/OV/shop/images/45_meeste_silmakreem.png\n/content/OV/shop/images/46_biotherm_komplekt.png\n/content/OV/shop/images/47_pintsetid.png\n/content/OV/shop/images/48_parfuumpihusti.png\n/content/OV/shop/images/49_pulsikell.png\n/content/OV/shop/images/4_olu_vinnutatud_veiseliha.png\n/content/OV/shop/images/50_korvaklapid.png\n/content/OV/shop/images/51_paljas_portmonee.png\n/content/OV/shop/images/52_priske_pisku.png\n/content/OV/shop/images/53_ostukott.png\n/content/OV/shop/images/54_mundikott.png\n/content/OV/shop/images/55_kaelakott.png\n/content/OV/shop/images/56_votmehoidja.png\n/content/OV/shop/images/57_glamorous_kaevoru.png\n/content/OV/shop/images/58_glamorous_korvarongad.png\n/content/OV/shop/images/59_classiccoin_kaevoru.png\n/content/OV/shop/images/5_vein_juustuvalik.png\n/content/OV/shop/images/60_classiccoin_korvarongad.png\n/content/OV/shop/images/61_winterdream_kaelaehe.png\n/content/OV/shop/images/62_winterdream_korvarongad.png\n/content/OV/shop/images/63_midnight_kaevoru.png\n/content/OV/shop/images/64_midnight_korvarongad.png\n/content/OV/shop/images/65_chupachups_seljakott.png\n/content/OV/shop/images/66_huulepalsamid.png\n/content/OV/shop/images/67_hansalinnad_kommid.png\n/content/OV/shop/images/68_kohvisokolaad.png\n/content/OV/shop/images/69_valge_sokolaad.png\n/content/OV/shop/images/6_kohv_muffin.png\n/content/OV/shop/images/70_EA_konjak.png\n/content/OV/shop/images/71_viruvalge_hobe.png\n/content/OV/shop/images/72_vana_tallinn.png\n/content/OV/shop/images/7_juustuvalik.png\n/content/OV/shop/images/8_pahklid.png\n/content/OV/shop/images/9_pringles.png\n";
        // Above is every product image in shop

        /* Some test statistics */
        $scope.requestsMade = 0;
        $scope.requestsSuccess = 0;
        $scope.requestsFailure = 0;
        $scope.requestsIncomplete = 0;
        $scope.totalResponseTime = 0;
        $scope.transferredMB = 0;
        var transferredBytes = 0;

        $scope.startTest = function () {
            $scope.stopTest();
            $scope.failedRequests = [];
            $scope.requestsMade = 0;
            $scope.requestsSuccess = 0;
            $scope.requestsFailure = 0;
            $scope.requestsIncomplete = 0;
            $scope.totalResponseTime = 0;
            $scope.transferredMB = 0;
            transferredBytes = 0;

            var urls = $scope.urlsToPing.split('\n');
            for (var i = 0; i < urls.length; i++) {
                for (var j = 0; j < $scope.numThreads; j++) {
                    var urlConfig = {};
                    urlConfig.url = urls[i];
                    var index = runningTests.push(urlConfig) - 1;
                    urlConfig.id = index;
                    urlConfig.timeout = spawnTest(index);
                }
            }

        };

        $scope.stopTest = function () {
            // Iterate over every test and stop it
            while (runningTests.length >0) {
                var test = runningTests.pop();
                clearTimeout(test.timeout);
            }
        };

        var spawnTest = function (testIndex) {
            // Spawn tests
            if (typeof (runningTests[testIndex]) === 'undefined') return;
            $scope.requestsMade += 1;
            var startDate = new Date();
            $http({
                method: 'GET',
                url: runningTests[testIndex].url+'?'+Math.random().toString(36),
                timeout: $scope.timeout,
                cache: false
            }).then(function success(data) {
                $scope.requestsSuccess += 1;
                if (data.headers('Content-Length')) {
                    transferredBytes += parseInt(data.headers('Content-Length'));
                    $scope.transferredMB = (transferredBytes/1024/1024).toFixed(2);
                }
                $scope.totalResponseTime += new Date() - startDate;
            }, function error(error, status) {
                $scope.requestsFailure += 1;
                $scope.failedRequests.push({
                    url: error.config.url.split('?')[0],
                    code: error.status,
                    details: error.statusText
                });
                console.log("Error", error.config.url, error);
            }).finally(function() {
                runningTests[testIndex].timeout = $timeout(
                    function() {
                        spawnTest(testIndex);
                    }, $scope.getFrequency*1000);
            });
        };

    }]);